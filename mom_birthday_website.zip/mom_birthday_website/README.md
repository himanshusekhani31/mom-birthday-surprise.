# For Mom, With Love — Birthday Website

A small, responsive birthday surprise website built with plain HTML, CSS, and JavaScript.

## Preview it
1. Extract the ZIP file.
2. Open `index.html` in Chrome, Edge, or another browser.
3. Use the photo chooser to add a favourite photo with Mom. The photo is only displayed locally in your browser.

## Share it as a link
The easiest option is GitHub Pages:
1. Sign in to GitHub and create a new public repository, for example `birthday-for-mom`.
2. Upload `index.html` from this folder and commit the change.
3. Open the repository's **Settings → Pages**.
4. Under the build/deployment section, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
5. Wait for GitHub Pages to publish the site. Its URL will look like `https://YOUR-USERNAME.github.io/birthday-for-mom/`.

You can also use another static hosting service. The website has no dependencies and does not collect or upload the selected photo.
